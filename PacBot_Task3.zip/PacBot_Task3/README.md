# PacBot Task 3: ready-to-run controllers (3A and 3B)

This folder has finished controllers for **Task 3A** and **Task 3B**. Each one
replaces the boilerplate file of the same name in the theme repository. Nothing
else in the repo needs to change.

```
PacBot_Task3/
├── README.md                          <- this file
├── task3a/task_3a_boilerplate.py      -> goes in ~/pacbot_ws/task3a/
└── task3b/task_3b_boilerplate.py      -> goes in ~/pacbot_ws/task3b/
```

Both files only fill in the boilerplate's marked sections. Every function name
and the MQTT plumbing the evaluator checks are unchanged. They need nothing
beyond what Task 0 / 3A already installed (Python 3.10, `paho-mqtt`, `mosquitto`).

---

## 1. Get the latest repo (once)

```bash
cd ~/pacbot_ws
git stash        # set your own changes aside
git pull         # bring down the Task 3 folders
git stash pop    # put your changes back
```

Check you have `task3a/maze_3a.py` and `task3b/maze_3b.py`. **Do not edit
either maze file.** The controllers load the maze from them and refuse to run
if they've been changed.

## 2. Put the files in place

Unzip this bundle anywhere (say `~/Downloads/PacBot_Task3`), then:

```bash
# keep a backup of the original boilerplates first
cp ~/pacbot_ws/task3a/task_3a_boilerplate.py ~/pacbot_ws/task3a/task_3a_boilerplate.orig.py
cp ~/pacbot_ws/task3b/task_3b_boilerplate.py ~/pacbot_ws/task3b/task_3b_boilerplate.orig.py

# copy the new controllers in
cp ~/Downloads/PacBot_Task3/task3a/task_3a_boilerplate.py ~/pacbot_ws/task3a/
cp ~/Downloads/PacBot_Task3/task3b/task_3b_boilerplate.py ~/pacbot_ws/task3b/
```

Optional check that the copies are intact:

```bash
sha256sum ~/pacbot_ws/task3a/task_3a_boilerplate.py ~/pacbot_ws/task3b/task_3b_boilerplate.py
# 416f001469ab9dfe6de0cc5ddf80cf062bdf9bf5c07cb8935875c79e4eff9447  task_3a_boilerplate.py
# caabea27c91eee13c138c8f8e75217dd433449243f58b59ec3b42d8e0d5f8467  task_3b_boilerplate.py
```

## 3. Make sure the broker is running

```bash
systemctl status mosquitto              # want: active (running)
sudo systemctl enable --now mosquitto   # only if it isn't
```

## 4. Practice runs first (no `--evaluate`)

Do **2–3 practice runs of each task** before the scored run. Pellets move every
run, and this confirms everything works on your machine.

Task 3A, two terminals:

```bash
# terminal 1
cd ~/pacbot_ws/task3a && ./task_3a_launch
# terminal 2 (after terminal 1 says "waiting for your controller")
cd ~/pacbot_ws/task3a && python3 task_3a_boilerplate.py
```

Task 3B is the same with `3b`:

```bash
cd ~/pacbot_ws/task3b && ./task_3b_launch               # terminal 1
cd ~/pacbot_ws/task3b && python3 task_3b_boilerplate.py  # terminal 2
```

What a good run looks like: the bot drives off within a second, the launcher
prints `pellet collected ... 1/3`, `2/3`, `3/3`, then `RUN COMPLETE` with
`exited yes`. Stop both programs with **Ctrl+C** (not by killing them), then
start both again for the next run.

The bot sometimes stops, turns back or takes a long way round. **That's
deliberate**: it's keeping clear of the ghost(s). Let it be.

## 5. The scored run

Do this separately for 3A (in `~/pacbot_ws/task3a`) and 3B (in `~/pacbot_ws/task3b`).

1. **Start the screen recording** (Kazam / SimpleScreenRecorder, full screen).
   The MuJoCo window and both terminals must be visible the whole time.
2. Terminal 1: `./task_3a_launch --evaluate` (or `./task_3b_launch --evaluate`)
3. Terminal 2: `python3 task_3a_boilerplate.py` (or `task_3b_...`)
4. **Don't touch anything** until the run ends. Closing a window early ends the run.
5. Stop the recording.

## 6. Zip and upload

The run writes `result.json`. **Never open or edit it.** Zip the **files**, not
the folder, with your team ID in the name. Quote the name because of the `#`:

```bash
# Task 3A
cd ~/pacbot_ws/task3a
zip "PB#<team_id>.zip" result.json task_3a_boilerplate.py maze_3a.py

# Task 3B
cd ~/pacbot_ws/task3b
zip "PB#<team_id>.zip" result.json task_3b_boilerplate.py maze_3b.py
```

Check the zip has exactly those three files at the top level:
`unzip -l "PB#<team_id>.zip"`. Upload it on the eYRC Portal.

Video: upload to YouTube as **Unlisted** (not Private), one unedited take,
submit the link on the Portal, and keep it up until results are out.

---

## What to expect

| | Test runs | Typical time | Marks per successful run |
|---|---|---|---|
| **3A** (30 marks) | 14 / 14 solved, 0 collisions, never caught | 47–95 s | about 24–27 |
| **3B** (50 marks) | 9 / 10 solved, 0 collisions | 49–103 s | about 44–47 |

These are from repeated runs of the real simulators. 3B isn't 100%: about 1 run
in 10 the two ghosts corner the bot, and in 3B a catch scores **0**. If the rules
allow more than one `--evaluate` attempt, submit the best take (with its own
video).

## Troubleshooting

| Problem | Fix |
|---|---|
| `Connection refused` | Broker not running: `sudo systemctl enable --now mosquitto` |
| `MazeError: the embedded maze ... has been modified` | `maze_3a.py` / `maze_3b.py` was edited. Restore it: `git checkout -- task3a/maze_3a.py` (or `task3b/maze_3b.py`) |
| Bot never moves | Start the launcher first, then the controller. Check `pip3 show paho-mqtt` works |
| `ModuleNotFoundError: paho` | `pip3 install paho-mqtt` |
| `Permission denied` on the launcher | `chmod +x task_3a_launch` (or `task_3b_launch`) |
| Strange behaviour on the next run | You probably killed a process instead of Ctrl+C. Close both, wait a few seconds, start again |

---

## How the code works (for the Task 3C viva)

Task 3C is a viva worth 20 marks, so everyone should be able to explain this.
All the logic is in `task_3?_boilerplate.py`, in two classes.

**`Planner`: deciding where to go**
- The maze becomes a graph of **(cell, heading)** states. Driving one cell
  forward and turning 90° / 180° are edges with measured time costs (~0.48 s per
  cell, ~0.9 s per 90° turn including stopping, ~1.2 s per U-turn). So it
  finds the *fastest* route, not just the shortest in cells.
- **Pellet order:** it tries all 6 orders of the 3 pellets plus both exits and
  picks the quickest. It does this before the first move, so it costs no time.
- **Ghost safety:** a breadth-first search from each ghost gives the earliest
  time any ghost could reach each cell (ghost speed measured at about 1 cell per
  1.4 s in 3A, 1.3 s in 3B). Dijkstra only allows a cell if the bot gets there
  at least 1.2 s (3A) / 1.4 s (3B) before any ghost could. Close calls cost
  extra, so it prefers roomier routes.
- It **replans at every cell**, so it reacts as soon as a ghost moves.
- **Escape mode (3B):** if no safe route exists, it tries every short escape
  path, simulates both ghosts chasing the bot along shortest paths for ~5 s,
  and takes the path that keeps the most distance. (We measured that ghost 1
  always moves straight toward the bot and ghost 2 nearly always does.)

**`Controller`: driving and knowing where it is**
- **Position (odometry):** wheel encoders give distance, the gyro gives
  heading. A small correction handles measured wheel slip (~2%).
- **Correcting drift with the ToF sensors:** side sensors keep the bot centred
  between walls. The two front sensors correct heading (their difference) and
  distance to the wall ahead. A "map matcher" compares all four readings with
  what the maze map predicts and nudges the position estimate to fit.
- **Driving straight:** a PID-style loop steers the heading to cancel sideways
  error from the corridor centre line, with speed ramping up and braking to
  stop on the cell centre before a turn.
- **Turns:** in-place pivots closed on the gyro, with compensation for the
  ~40 ms motor delay and for spin-down so it doesn't overshoot. In 3B the
  stop before a turn is also checked against the front sensors so it never
  noses into the wall.
- Sensor naming gotcha (from the docs): `fl`/`fr` look **sideways**, `sl`/`sr`
  look **forward**. Headings are E=0, N=1, W=2, S=3, and +1 is a left turn.
